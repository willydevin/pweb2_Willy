<?php $__env->startSection('title', 'Detail Pengaduan'); ?>
    
<?php $__env->startSection('css'); ?>
    <style>
        .text-primary:hover {
            text-decoration: underline;
        }

        .text-grey {
            color: #6c757d;
        }

        .text-grey:hover {
            color: #6c757d;
        }

        .btn-purple {
            background: #6a70fc;
            border: 1px solid #6a70fc;
            color: #fff;
            width: 100%;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    <a href="<?php echo e(route('pengaduan.index')); ?>" class="text-primary">Data Pengaduan</a>
    <a href="#" class="text-grey">/</a>
    <a href="#" class="text-grey">Detail Pengaduan</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-6 col-12">
            <div class="card">
                <div class="card-header">
                    <div class="text-center">
                        Pengaduan Masyarakat
                    </div>
                </div>
                <div class="card-body">
                    <table class="table">
                        <tbody>
                            <tr>
                                <th>NIK</th>
                                <td>:</td>
                                <td><?php echo e($pengaduan->nik); ?></td>
                            </tr>
                            <tr>
                                <th>Nama Masyarakat</th>
                                <td>:</td>
                                <td><?php echo e($pengaduan->user->nama); ?></td>
                            </tr>
                            <tr>
                                <th>Tanggal Pengaduan</th>
                                <td>:</td>
                                <td><?php echo e($pengaduan->tgl_pengaduan->format('d-M-Y')); ?></td>
                            </tr>
                            <tr>
                                <th>Foto</th>
                                <td>:</td>
                                <td><img src="<?php echo e(Storage::url($pengaduan->foto)); ?>" alt="Foto Pengaduan" class="embed-responsive"></td>
                            </tr>
                            <tr>
                                <th>Judul Laporan</th>
                                <td>:</td>
                                <td><?php echo e($pengaduan->judul_laporan); ?></td>
                            </tr>
                            <tr>
                                <th>Isi Laporan</th>
                                <td>:</td>
                                <td><?php echo e($pengaduan->isi_laporan); ?></td>
                            </tr>
                            <tr>
                                <th>Tanggal Kejadian</th>
                                <td>:</td>
                                <td><?php echo e($pengaduan->tgl_kejadian->format('d-M-Y')); ?></td>
                            </tr>
                            <tr>
                                <th>Kategori Kejadian</th>
                                <td>:</td>
                                <td><?php echo e(ucwords($pengaduan->kategori_kejadian)); ?></td>
                            </tr>
                            <tr>
                                <th>Status</th>
                                <td>:</td>
                                <td>
                                    <?php if($pengaduan->status == '0'): ?>
                                        <a href="" class="badge badge-danger">Pending</a>
                                    <?php elseif($pengaduan->status == 'proses'): ?>
                                        <a href="" class="badge badge-warning text-white">Proses</a>
                                    <?php else: ?>
                                        <a href="" class="badge badge-success">Selesai</a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <tr>
                                <th>Lokasi Kejadian</th>
                                <td>:</td>
                                <td><?php echo e($pengaduan->lokasi_kejadian); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="col-lg-6 col-12">
            <div class="card">
                <div class="card-header">
                    <div class="text-center">
                        Tanggapan Petugas
                    </div>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('tanggapan.createOrUpdate')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id_pengaduan" value="<?php echo e($pengaduan->id_pengaduan); ?>">
                        <div class="form-group">
                            <label for="status">Status</label>
                            <div class="input-group mb-3">
                                <select name="status" id="status" class="custom-select">
                                    <?php if($pengaduan->status == '0'): ?>
                                        <option selected value="0">Pending</option>
                                        <option value="proses">Proses</option>
                                        <option value="selesai">Selesai</option>
                                    <?php elseif($pengaduan->status == 'proses'): ?>
                                        <option value="0">Pending</option>
                                        <option selected value="proses">Proses</option>
                                        <option value="selesai">Selesai</option>
                                    <?php else: ?>
                                        <option value="0">Pending</option>
                                        <option value="proses">Proses</option>
                                        <option selected value="selesai">Selesai</option>
                                    <?php endif; ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="tanggapan">Tanggapana</label>
                            <textarea name="tanggapan" id="tanggapan" rows="4" class="form-control" placeholder="Belum ada tanggapan"><?php echo e($tanggapan->tanggapan ?? ''); ?></textarea>
                        </div>
                        <button type="submit" class="btn btn-purple">KIRIM</button>
                    </form>
                    <?php if(Session::has('status')): ?>
                        <div class="alert alert-success mt-2">
                            <?php echo e(Session::get('status')); ?>

                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ASUS\Downloads\pengaduan-masyarakat\resources\views/Admin/Pengaduan/show.blade.php ENDPATH**/ ?>