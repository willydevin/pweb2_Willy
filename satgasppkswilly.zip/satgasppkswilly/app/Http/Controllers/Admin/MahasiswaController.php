<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Mahasiswa;
use App\Models\Pengaduan;
use Illuminate\Http\Request;

class MahasiswaController extends Controller
{
    public function index()
    {
        $masyarakat = Mahasiswa::all();

        return view('Admin.Mahasiswa.index', ['mahasiswa' => $mahasiswa]);
    }

    public function show($nik)
    {
        $masyarakat = Mahasiswa::where('npm', $npm)->first();

        return view('Admin.Mahasiswa.show', ['mahasiswa' => $mahasiswa]);
    }

    public function destroy(Mahasiswa $mahasiswa)
    {
        $pengaduan = Pengaduan::where('npm', $mahasiswa->nik)->first();

        if (!$pengaduan) {
            $mahasiswa->delete();

            return redirect()->route('mahasiswa.index');
        } else {
            return redirect()->back()->with(['notif' => 'Can\'t delete. Masyarakat has a relationship!']);
        }
    }
}
